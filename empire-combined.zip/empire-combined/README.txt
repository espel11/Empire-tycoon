EMPIRE TYCOON — COMBINED EDITION

Corporation Simulator gameplay with the Empire Tycoon reference design:
blue gradient, white rounded cards, playful typography, green/gold actions,
compact financial dashboard and bottom navigation.

RUN
Extract this folder. With Python 3 installed, run:
  python3 -m http.server 8000
On Windows use: py -m http.server 8000
Open http://localhost:8000

FILES
index.html: complete game logic and embedded artwork.
theme.css: new visual design; edit this to customize the appearance.
preview.png: mobile preview.

Keep index.html and theme.css together when hosting. No build required.
Google Fonts requires internet; system fonts are the fallback.
The original recovered game remains in the separate corporation-simulator folder.
Saves use browser localStorage. Progress from a different website address does
not automatically transfer. Actions now save immediately to prevent losing a
recent purchase on reload.

CHECKED
All eight primary sections on a 390px viewport; business creation; immediate
reload persistence; desktop overflow at 1280px; no page JavaScript errors during
these checks. Full long-term economy and all advanced gameplay paths not tested.
This package has not been published to either Lovable site.
